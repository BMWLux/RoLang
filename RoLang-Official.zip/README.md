# RoLang

**RoLang** este un limbaj de programare minimalist, inspirat din Python (simplitate) și Lua (ușurință).  
Scopul lui este să ofere un limbaj foarte simplu pentru începători și experimente.

## 🚀 Instalare

```bash
git clone https://github.com/username/RoLang.git
cd RoLang
pip install .
```

## ▶️ Utilizare

Rulează REPL:
```bash
rolang
```

Rulează un fișier `.rol`:
```bash
rolang examples/hello.rol
```

## 📘 Tutorial

Vezi [docs/tutorial.md](docs/tutorial.md)
