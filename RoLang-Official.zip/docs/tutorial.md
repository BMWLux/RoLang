# 📘 Tutorial RoLang

## Primul program
```rolang
print("Salut lume!")
```

## Variabile
```rolang
x = 10
y = 3.5
nume = "Andrei"
print(x, y, nume)
```

## If / Else
```rolang
x = 5
if x < 7:
    print("mic")
else:
    print("mare")
```

## While
```rolang
i = 0
while i < 3:
    print(i)
    i = i + 1
```

## For
```rolang
for i in range(1, 5):
    print("Numar:", i)
```

## Funcții
```rolang
def salut(nume):
    print("Salut, " + nume)

salut("Maria")
```
