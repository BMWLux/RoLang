import sys

def run_code(code):
    # Simplu print interpreter (placeholder)
    try:
        exec(code, globals())
    except Exception as e:
        print("Eroare:", e)

def run_file(filename):
    with open(filename, "r") as f:
        code = f.read()
    run_code(code)

def repl():
    print("RoLang REPL v0.1")
    while True:
        try:
            line = input(">>> ")
            if line.strip().lower() in ["exit", "quit"]:
                break
            run_code(line)
        except EOFError:
            break
