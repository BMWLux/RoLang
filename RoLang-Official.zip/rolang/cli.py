import sys
from .interpreter import run_code, run_file, repl

def main():
    if len(sys.argv) > 1:
        run_file(sys.argv[1])
    else:
        repl()
